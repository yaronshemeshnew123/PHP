<?php
include '../include/functions.php';

$result = getCityByName( $_POST['city_name'] );
if( $result === false ){
    // insert new city data
    addNewCity( $_POST['city_name'], $_POST['dt_txt'], $_POST['temp_min'], $_POST['temp_max'], $_POST['wind']);
} else {
    // update exist city data
    updateCity( $result['c_id'], $_POST['dt_txt'], $_POST['temp_min'], $_POST['temp_max'], $_POST['wind'] );
}
echo json_encode( $result );