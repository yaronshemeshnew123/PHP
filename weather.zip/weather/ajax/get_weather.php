<?php
include '../include/functions.php';

$response = array();
$city= getCityByName( $_GET['city_name'] );
$temp = getCityTemp( $city['c_id'] );
$wind = getCityWind( $city['c_id'] );


$response['updated_at'] = $city['updated_at'];
$response['dt_txt'] = $temp['t_date_time'];
$response['temp_min'] = $temp['t_temp_min'];
$response['temp_max'] = $temp['t_temp_max'];
$response['speed'] = $wind['w_speed'];


echo json_encode( $response );