let data = {};
$('.from-api-btn').on('click', function( event) {
    // prevent from sending the form data to the server
    event.preventDefault();
    let city_name = $('.city-name').val();
    if( city_name.length > 0 ) {
        $.ajax({
            method: "GET",
            url: "http://api.openweathermap.org/data/2.5/forecast?q=" + city_name + "&units=metric&appid=e4b8b08c185638b825af37facfe1fabb"
        })
        .done(function (msg) {
            console.log(msg);
            // remove all previous rows
            $('.weather-row').remove();


            $('.starts-at').html( 'Starts at: ' + msg.list[0].dt_txt );
            $('.ends-at').html( 'Ends at: ' + msg.list[(msg.list.length-1)].dt_txt );
            $('.city-name-title').html(msg.city.name);

            // set the data of the first weather data for saving in the DB (if the user press the "SAVE" button )
            data.city_name = city_name;
            data.dt_txt = msg.list[0].dt_txt;
            data.temp_min = msg.list[0].main.temp_min;
            data.temp_max = msg.list[0].main.temp_max;
            data.wind = msg.list[0].wind.speed;

            for (let i = 0; i < msg.list.length; i++) {
                let html = '<tr class="weather-row">';
                html += '<td>' + msg.list[i].dt_txt + '</td>';
                html += '<td>' + msg.list[i].main.temp_min + '&deg;C</td>';
                html += '<td>' + msg.list[i].main.temp_max + '&deg;C</td>';
                html += '<td>' + msg.list[i].wind.speed + ' km/h</td>';
                html += '</td>';
                $('.table').append(html);
            }

            $('.weather_data').css('display', 'block' );
            $('.save-weather').css('display', 'inline');
        })
        .fail(function(res) {
            alert( 'City name is incorrect. Please type again.' );
            $('.city-name').focus();
        });
    } else {
        alert( 'Please enter city name' );
        $('.city-name').focus();
    }
});

$('.save-weather').on('click', function(event) {
    $.ajax({
        method: "POST",
        url: "ajax/save_weather.php",
        data: data
    })
    .done(function (msg) {
        console.log( msg );

    })
    .fail(function(res) {

    });
});

$('.from-db-btn').on('click', function( event) {
    // prevent from sending the form data to the server
    event.preventDefault();
    let city_name = $('.city-name').val();
    $.ajax({
        method: "GET",
        url: "ajax/get_weather.php",
        data: {
            city_name: city_name
        }
    })
    .done(function (msg) {
        msg = JSON.parse( msg );
        $('.weather-row').remove();
        $('.starts-at').html( 'Updated at: ' + msg.updated_at );
        $('.city-name-title').html(city_name);


        let html = '<tr class="weather-row">';
        html += '<td>' + msg.dt_txt + '</td>';
        html += '<td>' + msg.temp_min + '&deg;C</td>';
        html += '<td>' + msg.temp_max + '&deg;C</td>';
        html += '<td>' + msg.speed + ' km/h</td>';
        html += '</td>';
        $('.table').append(html);
        $('.weather_data').css('display', 'block' );
        $('.save-weather').css('display', 'none');
    })
    .fail(function(res) {
        alert( 'City name is incorrect. Please type again.' );
        $('.city-name').focus();
    });
});