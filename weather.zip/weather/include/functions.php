<?php
define('DB_HOST', "localhost");
define('DB_NAME', "weather_app");
define('DB_USER', "root");
define('DB_PASS', "");

// connect to the database
$conn = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
$conn->set_charset('utf8');

function getCityByName( $city_name ) {
    global $conn;
    $sql = "SELECT * FROM `city` WHERE `c_city_name`=?";
    $stmt = $conn->prepare( $sql );
    $stmt->bind_param('s', $city_name );
    $stmt->execute();
    $result = $stmt->get_result();
    if( $result->num_rows === 1 ) {
        $city = $result->fetch_assoc();
        return $city;
    } else {
        return false;
    }
}

function getCityTemp( $city_id ) {
    global $conn;
    $sql = "SELECT * FROM `temp` WHERE `t_city_id`=?";
    $stmt = $conn->prepare( $sql );
    $stmt->bind_param('i', $city_id );
    $stmt->execute();
    $result = $stmt->get_result();
    $city = $result->fetch_assoc();
    return $city;
}

function getCityWind( $city_id ) {
    global $conn;
    $sql = "SELECT * FROM `wind` WHERE `w_city_id`=?";
    $stmt = $conn->prepare( $sql );
    $stmt->bind_param('i', $city_id );
    $stmt->execute();
    $result = $stmt->get_result();
    $city = $result->fetch_assoc();
    return $city;
}

function addNewCity( $city_name, $datetime, $temp_min, $temp_max, $wind ) {
    global $conn;
    $sql = "INSERT INTO `city` (`c_city_name`) VALUES( ? )";
    $stmt = $conn->prepare( $sql );
    $stmt->bind_param('s', $city_name );
    $stmt->execute();
    $city_id = $stmt->insert_id;

    $sql = "INSERT INTO `temp` ( `t_date_time`, `t_temp_min`, `t_temp_max`, `t_city_id`) VALUES(?, ?, ?, ?)";
    $stmt = $conn->prepare( $sql );
    $stmt->bind_param('sddi', $datetime, $temp_min, $temp_max, $city_id );
    $stmt->execute();


    $sql = "INSERT INTO `wind` ( `w_speed`, `w_city_id` ) VALUES(?, ? )";
    $stmt = $conn->prepare( $sql );
    $stmt->bind_param('di', $wind, $city_id );
    $stmt->execute();
}

function updateCity( $city_id, $datetime, $temp_min, $temp_max, $wind ) {
    global $conn;
    $sql = "UPDATE `city` SET `updated_at`=now() WHERE `c_id`=?";
    $stmt = $conn->prepare( $sql );
    $stmt->bind_param('i', $city_id );
    $stmt->execute();

    $sql = "UPDATE `temp` SET `t_date_time`=?, `t_temp_min`=?, `t_temp_max`=? WHERE `t_city_id`=?";
    $stmt = $conn->prepare( $sql );
    $stmt->bind_param('sddi', $datetime, $temp_min, $temp_max, $city_id );
    $stmt->execute();


    $sql = "UPDATE `wind` SET `w_speed`=? WHERE `w_city_id`=?";
    $stmt = $conn->prepare( $sql );
    $stmt->bind_param('di', $wind, $city_id );
    $stmt->execute();
}